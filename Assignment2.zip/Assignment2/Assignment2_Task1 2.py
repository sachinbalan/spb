"""Write a Python program to implement your own myfilter()
function which works exactly like Python's built-in function filter()
"""
def main():
    #  List comprehensions to produce the following List ['A', 'C', 'A', 'D', 'G', 'I', ’L’, ‘ D’]
    print([i for i in 'ACADGILD'])
    #  List comprehensions to produce the following List ['x', 'xx', 'xxx', 'xxxx', 'y', 'yy', 'yyy', 'yyyy', 'z', 'zz', 'zzz', 'zzzz']
    print(print([n * i for i in ['x', 'y', 'z'] for n in [1, 2, 3, 4]]))
    #  List comprehensions to produce the following List ['x', 'y', 'z', 'xx', 'yy', 'zz', 'xx', 'yy', 'zz', 'xxxx', 'yyyy', 'zzzz']
    print(print([n*i if i!=3 else n*(i-1) for i in [1,2,3,4] for n in ['x','y','z'] ]))
    #  List comprehensions to produce the following List [[2], [3], [4], [3], [4], [5], [4], [5], [6]]
    print(print([[i+n] for i in range(0,3) for n in range(2,5) ]))
    #  List comprehensions to produce the following List [[2, 3, 4, 5], [3, 4, 5, 6], [4, 5, 6, 7], [5, 6, 7, 8]]
    print(print([[i + n for i in range(0, 4)] for n in range(2, 6)]))
    #  List comprehensions to produce the following List [(1, 1), (2, 1), (3, 1), (1, 2), (2, 2), (3, 2), (1, 3), (2, 3), (3, 3)]
    print(print([(n,i) for i in range(1, 4) for n in range(1, 4)]))
if __name__ == "__main__":
    main()