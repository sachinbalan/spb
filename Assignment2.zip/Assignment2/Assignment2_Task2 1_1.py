"""
Implement a function longestWord() that takes a list of words and returns the longest one
"""
class Complex_formatted(complex):
    def __format__(self, fmt):
        cfmt = "({:" + fmt + "}{:+" + fmt + "}j)"
        return cfmt.format(self.real, self.imag)
class Get_areas:
    def __init__(self, no_of_sides):
        self.n = no_of_sides
        self.sides = [0 for i in range(no_of_sides)]

    def inputSides(self):
        self.sides = [float(input("Enter side "+str(i+1)+" : ")) for i in range(self.n)]

    def dispSides(self):
        for i in range(self.n):
            print("Side",i+1,"is",self.sides[i])

class Triangle(Get_areas):
    def __init__(self,no_of_sides):
        Get_areas.__init__(self, no_of_sides)

    def findArea(self):
        a, b, c = self.sides
        # calculate the semi-perimeter
        s = (a + b + c) / 2
        area = (s * (s - a) * (s - b) * (s - c)) ** 0.5
        try:
            print('The area of the triangle is %6.2f:'%area)
        except TypeError:
            print('The area of the triangle if result is a complex number :', area.conjugate())

def main():
    get_area=Triangle(3)
    get_area.inputSides()
    get_area.dispSides()
    get_area.findArea()

if __name__ == "__main__":
    main()