"""Write a Python Program to implement your own myreduce()
function which works exactly like Python's built-in function reduce()
"""
def my_reduce(function, iterable):
    it = iter(iterable)
    value = next(it)
    for element in it:
        value = function(value, element)
    return value

def my_reduce_fuc(value, element):
    value=value+element
    return value

def main():
    list_num=[11,14,17,12]
    print("print sum of all values in list :",my_reduce(my_reduce_fuc,list_num))
    print("print largest number :",my_reduce(lambda a,b:a if a > b else b,list_num))

if __name__ == "__main__":
    main()