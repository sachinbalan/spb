
def get_longest_string(iterable,limit_number):
    longest_string_list=[]
    for x in iterable:
        if (len(x) > int(limit_number)):
            longest_string_list.append(x)
    return longest_string_list
def main():
    while True:
        try:
            input_number_value = input("enter words in a comma separated sequence :")
            if (len(input_number_value))==0:
                print ("No inputs given, Need to re enter input ")
            else:
                new_number_list=[]
                new_number_list=input_number_value.split(',')
                new_number_list =(list(map(lambda x:x.strip(),new_number_list)))
                break
        except ValueError:
            print('Please enter a whole number',input_number_value)
    print("values entered in list are :", new_number_list)
    limit_number=input("enter limit number :")
    print ("result is : ",get_longest_string(new_number_list,limit_number))


if __name__ == "__main__":
    main()