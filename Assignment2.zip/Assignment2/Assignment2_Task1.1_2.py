"""Write a Python program to implement your own myfilter()
function which works exactly like Python's built-in function filter()
"""
def my_filter_fuc(value):
    if type(value)==int:
        return True
    else:
        return False

def my_filter(function, iterable):
    for x in iterable:
        return_value=function(x)
        if (return_value == True):
            yield x

def main():
    list_num=[5,11,'s',17,'ty',12]
    print("return only intergers :",list(my_filter(my_filter_fuc,list_num)))
    print("print list if any number is greater than 10 number :",list(my_filter(lambda a: type(a)==int and a>10,list_num)))

if __name__ == "__main__":
    main()