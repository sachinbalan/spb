"""
Implement a function longestWord() that takes a list of words and returns the longest one
"""
def get_longest_string(iterable):
    longest_string_list=[]
    for x in iterable:
        if len(longest_string_list)==0: longest_string_list.append(x)
        elif  len(longest_string_list)!=0:
            flag=False
            for i in longest_string_list:
                if (len(x) > len(i)): flag = True
                elif (len(x) == len(i)): flag='Equal'
            if flag == True:
                longest_string_list=[]
                longest_string_list.append(x)
            if flag == 'Equal':longest_string_list.append(x)
    return longest_string_list

def main():
    list_num=['yyydy34ttt1y121','yyydyttty1','yyydyttdty1','yyydyttdty1','yyydy34ttty121','yyydyttty1','yyydy34ttty11']
    print("the longest item(s) from list are :",get_longest_string(list_num))

if __name__ == "__main__":
    main()