
def converter_func(iterable):
    string_list=[]
    for x in iterable:
        string_list.append(len(x))
    return string_list
def main():
    while True:
        try:
            input_number_value = input("enter words in a comma separated sequence :")
            if (len(input_number_value))==0:
                print ("No inputs given, Need to re enter input ")
            else:
                new_number_list=[]
                new_number_list=input_number_value.split(',')
                new_number_list =(list(map(lambda x:x.strip(),new_number_list)))
                break
        except ValueError:
            print('Please enter a whole number',input_number_value)
    print("values entered in list are :", new_number_list)
    print ("result is : ",converter_func(new_number_list))


if __name__ == "__main__":
    main()