import re
def vowels_checker(input_number_value):
    pattern_vowels = '([aeiouAEIOU])'
    result_flag=False
    if re.match(pattern_vowels, input_number_value):
        result_flag = True
    return (result_flag)

def main():
    pattern_alfa = '([a-zA-z])'
    while True:
        try:
            input_number_value = input("enter a letter (press '.' for exit from execution loop :")
            if re.match(pattern_alfa, input_number_value):
                print("the given letter is vowel", vowels_checker(input_number_value))
            if input_number_value == '.':break
        except:
            print("Not a letter - re enter input")

if __name__ == "__main__":
    main()