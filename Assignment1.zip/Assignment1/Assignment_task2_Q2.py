"""
Create the below pattern using nested for loop in Python.
"""
def main():

    pattern_list=['']
    for val,each_item in enumerate(range(9)):
        if val <5:pattern_list.append('*')
        elif val >4:pattern_list.pop()
        print(*pattern_list)

if __name__ == "__main__":
    main()