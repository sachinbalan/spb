"""Write a Python program to find the volume of a sphere with diameter 12 cm.
Formula: V=4/3 * π * r
"""
def  main():
    diameter_value = 12
    v=(4/3) * 3.14 * (diameter_value ** 3)
    print("volume of sphere :",v)

if __name__ == "__main__":
    main()