#Write a Python program to accept the user's first and last name and then getting them printed in
#the the reverse order with a space between first name and last name.

import functools
def  main():
    first_name = input("Enter your first name : ")
    last_name = input("Enter your last name : ")
    print(functools.reduce(lambda a,b:a[::-1]+' '+b[::-1],[first_name,last_name]))

if __name__ == "__main__":
    main()