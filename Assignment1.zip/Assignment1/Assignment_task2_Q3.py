"""
Write a Python program to reverse a word after accepting the input from the user.
"""
import functools
def  main():
    first_word = input("Enter your  word : ")
    print(first_word[::-1])

if __name__ == "__main__":
    main()