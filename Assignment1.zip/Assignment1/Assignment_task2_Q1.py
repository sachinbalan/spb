"""Write a program which accepts a sequence of comma-separated numbers from console and
generate a list.

"""
def main():
    while True:
        try:
            input_number_value = input("enter number in a comma separated sequence :")
            if (len(input_number_value))==0:
                print ("No inputs given, Need to re enter input ")
            else:
                new_number_list=[]
                new_number_list=input_number_value.split(',')
                new_number_list =(list(map(lambda x:x.strip(),new_number_list)))
                numeric_check=[False for x in new_number_list if not str(x).isnumeric()]
                if len(numeric_check)==0:
                    break
                else:
                    print ("All inputs are not numbers, Need to re enter input ")
        except ValueError:
            print('Please enter a whole number',input_number_value)
    print("final out put is  :", new_number_list)

if __name__ == "__main__":
    main()