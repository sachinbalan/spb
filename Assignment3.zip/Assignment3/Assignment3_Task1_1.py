def divide(x): 
    try: result = x // 0
    except ZeroDivisionError: result="Error happened when tried to multiply a number with zero "
    finally: return result

def main():
    while True:
        try:
            input_number_value = input("enter a number :")
            if (len(input_number_value))==0:
                print ("No inputs given, Need to re enter input ")
            else:
                input_number_value=input_number_value.strip()
                if input_number_value.isnumeric():
                    result=divide(int(input_number_value))
                    break
                else:
                    result="Reenter input - Input is not a number"
        except ValueError:
            print('Please enter a whole number',input_number_value)
            result="Reenter input - Input is not a number"
        finally:
            print ('entered number is:', input_number_value,"\t The result is :",result )
            
if __name__ == "__main__":
    main()