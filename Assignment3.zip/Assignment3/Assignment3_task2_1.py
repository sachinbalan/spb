import numpy as np

def matrix_func(input_vector, n, increasing=False):
    print("increasing",increasing)
    if not increasing:
        op_matx = np.array([x**(n-1-i) for x in input_vector for i in range(n)]).reshape(input_vector.size,n)
    elif increasing:
        op_matx = np.array([x**i for x in input_vector for i in range(n)]).reshape(input_vector.size,n)
    
    return op_matx

def main():
    input_vector = np.array([3,5,7,9])
    coloum_number = 3
    op_matx_dec_order = matrix_func(input_vector,coloum_number,False)
    op_matx_inc_order = matrix_func(input_vector,coloum_number,True)

    print("The input array is:",input_vector,"\n")
    print("Number of columns in output matrix should be:",coloum_number,"\n")
    print("Vander matrix of the input array in decreasing order of powers:\n\n",op_matx_dec_order,"\n")
    print("Vander matrix of the input array in increasing order of powers:\n\n",op_matx_inc_order,"\n")
         
if __name__ == "__main__":
    main()