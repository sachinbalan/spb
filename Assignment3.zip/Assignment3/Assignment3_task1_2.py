"""Implement a Python program to generate all sentences where subject is in ["Americans",
"Indians"] and verb is in ["Play", "watch"] and the object is in ["Baseball","cricket"]."""

def main():
    subjects=["Americans","Indians"]
    verbs=["play","watch"]
    objects=["Baseball","Cricket"]    for i in subjects:        for j in verbs:            for k in objects:                print (i,j,k+'.')            
if __name__ == "__main__":
    main()